// test-flow.js — pilih level, modal konfirmasi, kirim hasil ke backend (backup)
(function () {
  const overlay = document.getElementById('modalOverlay');
  const modal = overlay.querySelector('.modal');
  const modalBody = document.getElementById('modalBody');
  const btnYes = document.getElementById('btnYes');
  const btnNo = document.getElementById('btnNo');
  const statusEl = document.getElementById('statusMessage');

  const levelLabels = { acak: 'Level Acak', smp: 'setingkat SMP', sma: 'setingkat SMA/SMK' };
  let selectedLevel = null;
  let lastTrigger = null;

  function openModal(level, triggerEl) {
    selectedLevel = level;
    lastTrigger = triggerEl;
    modalBody.textContent = level === 'sma'
      ? 'Kamu pilih ' + levelLabels[level] + '. Soalnya bakal cukup menantang, bisa jadi ada yang di luar kemampuanmu sekarang — dan itu wajar.'
      : 'Kamu pilih ' + levelLabels[level] + '. Sistem akan menyesuaikan soal berdasarkan pilihanmu ini.';
    overlay.classList.add('show');
    overlay.removeAttribute('hidden');
    btnNo.focus();
    document.addEventListener('keydown', onKeydown);
  }

  function closeModal() {
    overlay.classList.remove('show');
    overlay.setAttribute('hidden', '');
    document.removeEventListener('keydown', onKeydown);
    if (lastTrigger) lastTrigger.focus();
  }

  function onKeydown(e) {
    if (e.key === 'Escape') { closeModal(); return; }
    // focus trap sederhana: Tab di dalam modal saja
    if (e.key === 'Tab') {
      const focusables = modal.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  }

  document.querySelectorAll('.level-btns button').forEach(btn => {
    btn.addEventListener('click', () => openModal(btn.dataset.level, btn));
  });

  btnNo.addEventListener('click', closeModal);

  btnYes.addEventListener('click', async () => {
    closeModal();
    await kirimHasilKeBackend({
      level: selectedLevel,
      waktu: new Date().toISOString(),
      status: 'tes-dimulai' // placeholder: bank soal asli belum terpasang
    });
  });

  function showStatus(message, kind) {
    statusEl.textContent = message;
    statusEl.className = 'status-message show ' + kind;
  }

  // Kirim ke backend Flask untuk backup. Kalau backend belum jalan (mis. buka
  // langsung dari file://), simpan cadangan lokal supaya data tidak hilang.
  async function kirimHasilKeBackend(payload) {
    try {
      const res = await fetch('/api/hasil-tes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error('Respons server tidak OK: ' + res.status);
      showStatus('Tersimpan di server. Bank soal untuk level ini menyusul di tahap berikutnya.', 'ok');
    } catch (err) {
      simpanCadanganLokal(payload);
      showStatus('Server belum terhubung — hasil disimpan sementara di perangkat ini.', 'error');
    }
  }

  function simpanCadanganLokal(payload) {
    try {
      const key = 'tka-ixf:cadangan-hasil';
      const existing = JSON.parse(localStorage.getItem(key) || '[]');
      existing.push(payload);
      localStorage.setItem(key, JSON.stringify(existing));
    } catch (e) {
      // Kalau localStorage juga gagal (mis. mode private), tidak ada yang bisa dilakukan lagi di sisi klien.
      console.error('Gagal menyimpan cadangan lokal:', e);
    }
  }
})();
