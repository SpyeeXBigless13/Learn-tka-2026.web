// navigation.js — perpindahan tab utama, dengan atribut aria yang benar
(function () {
  const tabs = ['home', 'sistem', 'belajar'];

  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const selected = btn.dataset.tab;

      document.querySelectorAll('.tab-btn').forEach(b => {
        const isActive = b.dataset.tab === selected;
        b.classList.toggle('active', isActive);
        if (isActive) {
          b.setAttribute('aria-current', 'page');
        } else {
          b.removeAttribute('aria-current');
        }
      });

      tabs.forEach(t => {
        const panel = document.getElementById('tab-' + t);
        const visible = t === selected;
        panel.style.display = visible ? 'block' : 'none';
        panel.toggleAttribute('hidden', !visible);
      });
    });
  });
})();
