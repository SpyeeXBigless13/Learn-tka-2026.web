// loading.js — animasi teks jatuh + transisi ke homepage
(function () {
  const title = "SELAMAT BELAJAR TKA IX-F";
  const fallEl = document.getElementById('fallTitle');

  // aria-hidden pada karakter dekoratif; teks utuh dibaca lewat aria-label di parent
  fallEl.setAttribute('aria-label', title);
  fallEl.setAttribute('role', 'text');

  [...title].forEach((ch, i) => {
    const span = document.createElement('span');
    span.setAttribute('aria-hidden', 'true');
    span.textContent = ch === " " ? "\u00A0" : ch;
    span.style.animationDelay = (0.5 + i * 0.045) + "s";
    fallEl.appendChild(span);
  });

  const loadingEl = document.getElementById('loading');
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const delay = prefersReducedMotion ? 400 : 2600;

  setTimeout(() => {
    loadingEl.classList.add('hide');
    // pindahkan fokus ke konten utama untuk pengguna keyboard/screen reader
    const main = document.getElementById('main-content');
    if (main) main.setAttribute('tabindex', '-1');
    if (main) main.focus({ preventScroll: true });
  }, delay);
})();
