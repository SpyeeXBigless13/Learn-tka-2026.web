// support.js — alur "Dukung Kami" (Ya/Tidak) di tengah homepage
(function () {
  const btnYes = document.getElementById('supportYes');
  const btnLater = document.getElementById('supportLater');
  const msg = document.getElementById('supportMessage');

  if (!btnYes || !btnLater) return;

  btnYes.addEventListener('click', async () => {
    // Belum ada kanal donasi resmi (rekening/QRIS) yang terpasang di proyek ini.
    // Daripada pura-pura ada tombol donasi yang sebenarnya tidak ke mana-mana,
    // ajak share link-nya dulu -- itu bantuan paling nyata yang bisa diminta sekarang.
    const url = window.location.href;
    const teks = 'Aku lagi coba TKA IX-F buat latihan TKA gratis, kamu juga cobain yuk!';

    if (navigator.share) {
      try {
        await navigator.share({ title: 'TKA IX-F', text: teks, url });
        msg.textContent = 'Makasih sudah mau bagikan! 🙌';
      } catch (e) {
        // pengguna membatalkan share dialog -- tidak perlu tampilkan error
      }
    } else if (navigator.clipboard) {
      await navigator.clipboard.writeText(url);
      msg.textContent = 'Link sudah disalin — tinggal kirim ke temanmu.';
    } else {
      msg.textContent = 'Bagikan link ini ke temanmu: ' + url;
    }
    msg.className = 'status-message show ok';
  });

  btnLater.addEventListener('click', () => {
    msg.textContent = 'Oke, gapapa. Tetap semangat belajarnya ya.';
    msg.className = 'status-message show ok';
  });
})();
